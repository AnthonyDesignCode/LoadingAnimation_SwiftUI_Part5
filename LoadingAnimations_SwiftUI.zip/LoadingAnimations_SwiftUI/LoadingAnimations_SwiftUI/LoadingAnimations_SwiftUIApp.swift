//
//  LoadingAnimations_SwiftUIApp.swift
//  LoadingAnimations_SwiftUI
//
//  Created by Anthony Codes on 13/08/2020.
//

import SwiftUI

@main
struct LoadingAnimations_SwiftUIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
